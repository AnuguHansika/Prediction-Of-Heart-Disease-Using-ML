document.getElementById('prediction-form').addEventListener('submit', function (e) {
  e.preventDefault();

  var xhr = new XMLHttpRequest();
  var url = '/predict';
  var formData = new FormData(this);

  xhr.open('POST', url, true);
  xhr.onreadystatechange = function () {
    if (xhr.readyState === 4 && xhr.status === 200) {
      var predictionResult = JSON.parse(xhr.responseText);
      if (predictionResult.result) {
        document.getElementById('prediction-result').innerHTML = 'Heart disease Prediction: ' + predictionResult.result;
        document.getElementById('prediction-result').classList.add('success');
      } else {
        document.getElementById('prediction-result').innerHTML = 'Failed to make a prediction. Please provide all 13 attributes.';
        document.getElementById('prediction-result').classList.add('fail');
      }
    }
  };
  xhr.send(formData);
});