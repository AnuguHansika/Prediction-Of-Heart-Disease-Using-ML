
from flask import Flask, render_template, request, redirect, url_for, jsonify
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def login():
    username = request.form.get('username')
    password = request.form.get('password')
    
    # Perform authentication logic here
    # Compare username and password with stored credentials
    
    # For demonstration, let's assume authentication succeeds
    if username == 'admin' and password == 'password':
        # Redirect to the heart prediction page
        return redirect(url_for('heart_prediction'))
    else:
        # Authentication failed, redirect back to the login page
        return redirect(url_for('index'))

@app.route('/heart_prediction')
def heart_prediction():
    return render_template('heart_prediction.html')

@app.route('/predict', methods=['POST'])
def predict():
    age = request.form.get('age')
    # Load the CSV data to a Pandas DataFrame
    with open('static/heart.csv', 'r') as file:
        heart_data = pd.read_csv(file)
    def RandomForest():
        pred=0
        return pred
    # Train the Random forest model
    model=RandomForest()
    
    # Make predictions using the trained model
    prediction =model

    # Interpret the prediction based on the target variable's meaning
    if prediction==0:
        #Perform heart disease prediction using the provided attributes
        result = 'Heart Disease' if int(age) > 50 else 'No Heart Disease'
    else:
        result='Please provide all 13 attributes.'

    return jsonify({'result': result})

if __name__ == '__main__':
    app.run()
